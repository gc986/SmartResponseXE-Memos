## ATmega128RFA1 ATmegaBOOT Bootloader

To make the bootloader for the ATmega128RFA1 Dev board enter:

	make atmega128rfa1

Or to make and program, enter:

	make atmega128rfa1_isp